import React from 'react';
import {Table, Button, Form } from 'react-bootstrap';
import { Link, BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import Auth from './components/auth/Auth';
import Main from './components/main/Main';
import Out from './components/out/Out';
import Fetch from './components/fetch/Fetch';
import Verify from './components/verify/Verify';
import Del from './components/del/del';
function App() {
  return (
    <div className="App">
      <Router>
     
           
<Switch>
          <Route path='/auth' component={Auth} />
          <Route path='/main' component={Main} />

          <Route path='/fetch' component={Fetch} />
          <Route path='/verify' component={Verify} />
          <Route path="/out" component={Out} />
          <Route path="/del" component={Del} />
          <Redirect to='/auth' from='*' />
        </Switch>

      </Router>
    </div>
        
  );
}

export default App;


