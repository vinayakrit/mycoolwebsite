const config = {
    apiServerAddress: 'http://127.0.0.1:3002'
};

export default config;