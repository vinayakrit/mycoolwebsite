import firebase from 'firebase';

const config = {
    apiKey: "AIzaSyCZ8IoithO6ONZR4A7tmdojEzUGSW1oIWM",
    authDomain: "cap-bl.firebaseapp.com",
    projectId: "cap-bl",
    storageBucket: "cap-bl.appspot.com",
    messagingSenderId: "693779600771",
    appId: "1:693779600771:web:8710d31336084a6e6392b6",
    measurementId: "G-2XYQT4DWS5"
};

// Initialize Firebase
firebase.initializeApp(config);

export const auth = firebase.auth();

